// Equity Bank Rwanda mini-app
console.log("Equity Bank Rwanda app initialized");