// Equity Bank Rwanda 페이지 초기화
console.log("Equity Bank Rwanda mini-app loaded");