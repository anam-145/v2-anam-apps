// ================================================================
// Dogecoin Index Page Script
// ================================================================

(function() {
  'use strict';

  // Get adapter and config
  const adapter = window.getAdapter();
  const config = window.getCoinConfig();

  // ================================================================
  // Create New Wallet
  // ================================================================
  
  window.createWallet = async function() {
    try {
      // Generate random mnemonic (dummy)
      const dummyMnemonic = "word1 word2 word3 word4 word5 word6 word7 word8 word9 word10 word11 word12";
      const wallet = await adapter.generateWalletFromMnemonic(dummyMnemonic);
      
      alert(`Wallet Created!\n\nAddress: ${wallet.address}\n\nIMPORTANT: This is a demo wallet with no real functionality.`);
      console.log('[Dogecoin] New wallet created:', wallet.address);
    } catch (error) {
      console.error('Error creating wallet:', error);
      alert('Failed to create wallet. Please try again.');
    }
  };

  // ================================================================
  // Import from Mnemonic
  // ================================================================
  
  window.importFromMnemonic = async function() {
    const mnemonicInput = document.getElementById('mnemonic-input');
    const mnemonic = mnemonicInput.value.trim();
    
    if (!mnemonic) {
      alert('Please enter your mnemonic phrase.');
      return;
    }
    
    // Validate mnemonic (12 or 24 words)
    const words = mnemonic.split(/\s+/);
    if (words.length !== 12 && words.length !== 24) {
      alert('Mnemonic must be 12 or 24 words.');
      return;
    }
    
    try {
      const wallet = await adapter.generateWalletFromMnemonic(mnemonic);
      
      alert(`Wallet Imported Successfully!\n\nAddress: ${wallet.address}\n\nNOTE: This is a demo wallet with no real functionality.`);
      console.log('[Dogecoin] Wallet imported from mnemonic:', wallet.address);
      
      // Clear input
      mnemonicInput.value = '';
    } catch (error) {
      console.error('Error importing wallet:', error);
      alert('Failed to import wallet. Please check your mnemonic and try again.');
    }
  };

  // ================================================================
  // Import from Private Key
  // ================================================================
  
  window.importFromPrivateKey = async function() {
    const privatekeyInput = document.getElementById('privatekey-input');
    const privateKey = privatekeyInput.value.trim();
    
    if (!privateKey) {
      alert('Please enter your private key.');
      return;
    }
    
    try {
      const wallet = await adapter.generateWalletFromPrivateKey(privateKey);
      
      alert(`Wallet Imported Successfully!\n\nAddress: ${wallet.address}\n\nNOTE: This is a demo wallet with no real functionality.`);
      console.log('[Dogecoin] Wallet imported from private key:', wallet.address);
      
      // Clear input
      privatekeyInput.value = '';
    } catch (error) {
      console.error('Error importing wallet:', error);
      alert('Failed to import wallet. Please check your private key and try again.');
    }
  };

  // ================================================================
  // Initialization
  // ================================================================
  
  console.log(`[${config.name}] Index page initialized`);
  console.log(`[${config.name}] Theme colors:`, config.theme);
  
})();