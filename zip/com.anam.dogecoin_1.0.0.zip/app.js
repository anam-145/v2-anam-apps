// ================================================================
// DOGECOIN 미니앱 전역 설정 및 초기화
// ================================================================

// Coin 설정
const CoinConfig = {
  // 기본 정보
  name: "Dogecoin",
  symbol: "DOGE",
  decimals: 8,
  
  // UI 테마 설정
  theme: {
    primaryColor: "#D4A76A",      // 도지코인 골드
    secondaryColor: "#BA9F33",     // 도지코인 다크 골드
    logoText: "Dogecoin",
  },
  
  // 주소 설정
  address: {
    // 도지코인 주소 형식 (Bitcoin과 유사)
    regex: /^(D[5-9A-HJ-NP-U][1-9A-HJ-NP-Za-km-z]{32})$/,
    displayFormat: "D...",
  },
};

// ================================================================
// CoinAdapter 베이스 클래스
// ================================================================
class CoinAdapter {
  constructor(config) {
    this.config = config;
    this.wallet = null;
  }

  // 지갑 생성 (니모닉)
  async generateWalletFromMnemonic(mnemonic) {
    // 실제 구현 없이 더미 데이터 반환
    return {
      address: "DExampleDogeAddress1234567890",
      privateKey: "dummy_private_key",
      mnemonic: mnemonic
    };
  }

  // 지갑 생성 (프라이빗 키)
  async generateWalletFromPrivateKey(privateKey) {
    // 실제 구현 없이 더미 데이터 반환
    return {
      address: "DExampleDogeAddress1234567890",
      privateKey: privateKey
    };
  }

  // 잔액 조회
  async getBalance(address) {
    // 더미 잔액 반환
    return "1000.00";
  }
}

// ================================================================
// DogecoinAdapter 구현
// ================================================================
class DogecoinAdapter extends CoinAdapter {
  constructor(config) {
    super(config);
  }
}

// ================================================================
// 전역 설정
// ================================================================

// 전역 어댑터 인스턴스
let globalAdapter = null;

// 어댑터 설정
window.setAdapter = function(adapter) {
  globalAdapter = adapter;
  console.log('[Dogecoin] Adapter initialized');
};

// 어댑터 가져오기
window.getAdapter = function() {
  if (!globalAdapter) {
    globalAdapter = new DogecoinAdapter(CoinConfig);
  }
  return globalAdapter;
};

// Coin 설정 가져오기
window.getCoinConfig = function() {
  return CoinConfig;
};

// 초기 어댑터 설정
window.setAdapter(new DogecoinAdapter(CoinConfig));